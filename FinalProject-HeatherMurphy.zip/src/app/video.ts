export class Video {

}
