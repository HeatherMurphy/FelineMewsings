export interface id {
  videoId: string;
}
