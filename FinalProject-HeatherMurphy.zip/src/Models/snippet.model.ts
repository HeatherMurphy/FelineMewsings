export interface snippet {
  title: string;
  description: string;
  channelId: string;
}
